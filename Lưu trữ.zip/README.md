# Speed reading server

## Getting Started

Install dependencies

```
npm install
```

Running in development

```
npm run dev
```

Running in production

```
npm start
```

Running tests / linting

```
npm test

npm run lint
```
